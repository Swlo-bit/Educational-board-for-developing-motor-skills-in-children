#include <Adafruit_NeoPixel.h>
#include "mp3tf16p.h"

unsigned long tDebug = 0;
const unsigned long DEBUG_INTERVAL = 500;  // cambia esto a tu gusto (ms)

// ===== COLORES LÓGICOS =====
#define C_ROJO 0
#define C_AZUL 1
#define C_AMARILLO 2
#define C_VERDE 3
#define C_MORADO 4
#define C_BLANCO 5
#define C_CELESTE 7
#define C_GRIS 9

#define TOTAL_COLORES_AUDIO 3

int coloresAudio[TOTAL_COLORES_AUDIO] = {
  C_ROJO,
  C_AZUL,
  C_AMARILLO
};

#define PIN 7
#define NUM_LEDS 64
#define NUM_ZONAS 16  // total de zonas

Adafruit_NeoPixel strip(NUM_LEDS, PIN, NEO_RGB + NEO_KHZ800);

MP3Player mp3(Serial2);
#define VOL_AUDIO 28

#define MODO_1 49
#define MODO_3 9
#define IDIOMA 10
#define KICHWA 50

#define MODO_PAR 2
#define MODO_COLOR 3

int modoActual = MODO_PAR;
int modoAnterior = -1;

// ===== FILTRO POR TIEMPO =====
const unsigned long TIEMPO_MIN_TOQUE = 300;  // ms → CAMBIA AQUÍ (ej: 300, 500, 1000)

unsigned long tiempoInicioToque[NUM_ZONAS];
bool toqueValidado[NUM_ZONAS];

// ===== COLORES =====
#define ROJO 255, 0, 0
#define VERDE 0, 255, 0
#define AZUL 0, 0, 255
#define AMARILLO 255, 255, 0
#define MORADO 255, 0, 255
#define CELESTE 0, 255, 255
#define GRIS 100, 100, 100
#define BLANCO 255, 255, 255
#define APAGADO 0, 0, 0


// MODO 1
// MODO 4
#define MODO_COLOR_TOTAL 4
#define TOTAL_COLORES 8

int coloresDisponibles[TOTAL_COLORES] = {
  C_ROJO,
  C_AZUL,
  C_AMARILLO,
  C_VERDE,
  C_MORADO,
  C_BLANCO,
  C_CELESTE,
  C_GRIS,

};

int colorZona[NUM_ZONAS];
int colorObjetivo4;

bool tableroListo4 = false;

// MODO 2
// ===== MODO 2 =====
int par1 = -1;
int par2 = -1;

int seleccion1 = -1;
int seleccion2 = -1;

bool mostrandoPar = true;
bool esperandoPar = false;

// color del par
#define COLOR_PAR AZUL

//MODO 3

#define COLOR_INIT 0
#define COLOR_MOSTRAR 1
#define COLOR_ESPERAR 2

int colorActual = 0;
int zonaCorrecta = 0;
byte estadoColor = COLOR_INIT;
unsigned long tColor = 0;

#define IDIOMA_INGLES 0
#define IDIOMA_ESP 1
#define IDIOMA_KICHWA 2

byte idiomaActual = IDIOMA_ESP;  // por defecto español



// ===== ARRAYS DE ZONAS =====
int zonaInicio[NUM_ZONAS] = {
  0, 4, 8, 12, 16, 20, 24, 28,
  32, 36, 40, 44, 48, 52, 56, 60
};

int zonaFin[NUM_ZONAS] = {
  3, 7, 11, 15, 19, 23, 27, 31,
  35, 39, 43, 47, 51, 55, 59, 63
};

// Pines de sensores por zona
int sensorPin[NUM_ZONAS] = {
  22, 23, 24, 25, 26, 27, 28, 29,
  30, 31, 32, 33, 34, 35, 36, 37
};

// ESTADO
bool estadoAnterior[NUM_ZONAS];

// ===== ZONAS DE FEEDBACK =====
int zonasFeedback[] = { 0, 3, 15, 12 };
int totalZonasFeedback = sizeof(zonasFeedback) / sizeof(zonasFeedback[0]);

void setup() {
  strip.begin();
  strip.show();
  mp3.initialize();

  Serial.begin(9600);

  randomSeed(analogRead(A0));

  for (int i = 0; i < NUM_ZONAS; i++) {
    pinMode(sensorPin[i], INPUT);
    estadoAnterior[i] = LOW;  // estado inicial
  }
  for (int i = 0; i < NUM_ZONAS; i++) {
    pinMode(sensorPin[i], INPUT);
    estadoAnterior[i] = LOW;
    tiempoInicioToque[i] = 0;
    toqueValidado[i] = false;
  }

  pinMode(MODO_1, INPUT_PULLUP);
  pinMode(MODO_3, INPUT_PULLUP);
  pinMode(IDIOMA, INPUT_PULLUP);
  pinMode(KICHWA, INPUT_PULLUP);


  generarPar();
}


//funcion denbug
void mostrarSensoresMatriz() {

  Serial.println();
  Serial.println("Sensores [zona]=estado (1=TOQUE, 0=LIBRE)");

  for (int fila = 0; fila < 4; fila++) {
    for (int col = 0; col < 4; col++) {

      int z = fila * 4 + col;
      int v = digitalRead(sensorPin[z]);

      Serial.print("[");
      if (z < 10) Serial.print("0");  // para alinear
      Serial.print(z);
      Serial.print("]");
      Serial.print(v);
      Serial.print(" ");
    }
    Serial.println();
  }

  Serial.println("------------------------");
}
void apagarTodo() {
  for (int i = 0; i < NUM_LEDS; i++) {
    strip.setPixelColor(i, 0);
  }
  strip.show();
}
void mostrarInputs() {

  Serial.print("INPUTS → ");

  Serial.print("MODO_1(49)=");
  Serial.print(digitalRead(MODO_1));

  Serial.print("  MODO_3(9)=");
  Serial.print(digitalRead(MODO_3));

  Serial.print("  IDIOMA(10)=");
  Serial.println(digitalRead(IDIOMA));
}


// ---------- Funciones ----------
int leerZonaTocada() {

  unsigned long ahora = millis();

  for (int z = 0; z < NUM_ZONAS; z++) {

    bool estadoActual = digitalRead(sensorPin[z]);

    // Inicio de toque
    if (estadoActual == HIGH && estadoAnterior[z] == LOW) {
      estadoAnterior[z] = HIGH;
      tiempoInicioToque[z] = ahora;
      toqueValidado[z] = false;
    }

    // Mantiene el toque
    if (estadoActual == HIGH && estadoAnterior[z] == HIGH) {

      if (!toqueValidado[z] && (ahora - tiempoInicioToque[z] >= TIEMPO_MIN_TOQUE)) {
        toqueValidado[z] = true;
        return z;  // ✅ toque válido
      }
    }

    // Se soltó el sensor
    if (estadoActual == LOW) {
      estadoAnterior[z] = LOW;
      tiempoInicioToque[z] = 0;
      toqueValidado[z] = false;
    }
  }

  return -1;
}

void encenderZona(int zona, uint8_t r, uint8_t g, uint8_t b) {
  for (int i = zonaInicio[zona]; i <= zonaFin[zona]; i++) {
    strip.setPixelColor(i, strip.Color(r, g, b));
  }
  strip.show();
}

void apagarZona(int zona) {
  for (int i = zonaInicio[zona]; i <= zonaFin[zona]; i++) {
    strip.setPixelColor(i, 0);
  }
  strip.show();
}

void parpadearFeedback(uint8_t r, uint8_t g, uint8_t b) {
  apagarTodo();
  for (int i = 0; i < 2; i++) {

    for (int j = 0; j < totalZonasFeedback; j++) {
      encenderZona(zonasFeedback[j], r, g, b);
    }
    delay(200);

    for (int j = 0; j < totalZonasFeedback; j++) {
      apagarZona(zonasFeedback[j]);
    }
    delay(200);
  }
}



void leerModo() {

  bool botonModo1 = (digitalRead(MODO_1) == LOW);
  bool botonModo3 = (digitalRead(MODO_3) == LOW);
  Serial.print("------------------------");
  int val1 = digitalRead(MODO_1);
  // Serial.print("modo1");
  // Serial.println(val1);

  int val2 = digitalRead(MODO_3);
  // Serial.print("modo3");
  // Serial.println(val2);

  int nuevoModo = modoActual;

  // 🔹 lógica acordada
  if (!botonModo1 && !botonModo3) {
    nuevoModo = MODO_PAR;
  } else if (botonModo1) {
    nuevoModo = MODO_COLOR_TOTAL;
  } else if (botonModo3) {
    nuevoModo = MODO_COLOR;
  }

  // 🔹 solo si cambia el modo
  if (nuevoModo != modoActual) {
    modoAnterior = modoActual;
    modoActual = nuevoModo;
    apagarTodo();
    resetearEstados();

    // debug claro
    // Serial.print("Cambio de modo → ");
    // if (modoActual == MODO_MEMORIA) Serial.println("MEMORIA");
    // else if (modoActual == MODO_PAR) Serial.println("PAR");
    // else if (modoActual == MODO_COLOR) Serial.println("COLOR");
  }
}



void resetearEstados() {

  // MODO 1
  tableroListo4 = false;


  // MODO 2
  mostrandoPar = true;
  esperandoPar = false;
  seleccion1 = -1;
  seleccion2 = -1;

  // MODO 3
  estadoColor = COLOR_INIT;

  for (int i = 0; i < NUM_ZONAS; i++) {
    estadoAnterior[i] = LOW;
  }
}



//MODO 1
void encenderZonaColor(int zona, int color) {

  switch (color) {

    case C_ROJO: encenderZona(zona, ROJO); break;
    case C_AZUL: encenderZona(zona, AZUL); break;
    case C_AMARILLO: encenderZona(zona, AMARILLO); break;
    case C_VERDE: encenderZona(zona, VERDE); break;
    case C_MORADO: encenderZona(zona, MORADO); break;
    case C_BLANCO: encenderZona(zona, BLANCO); break;
    case C_CELESTE: encenderZona(zona, CELESTE); break;
    case C_GRIS: encenderZona(zona, GRIS); break;
  }
}
void generarModo4() {

  apagarTodo();

  // 1️⃣ elegir color objetivo
  colorObjetivo4 = coloresAudio[random(0, TOTAL_COLORES_AUDIO)];

  bool existeObjetivo = false;

  // 2️⃣ pintar tablero aleatorio
  for (int i = 0; i < NUM_ZONAS; i++) {

    int c = coloresDisponibles[random(0, TOTAL_COLORES)];
    colorZona[i] = c;

    if (c == colorObjetivo4) {
      existeObjetivo = true;
    }

    encenderZonaColor(i, c);
  }

  // 3️⃣ asegurar que exista al menos 1 zona correcta
  if (!existeObjetivo) {
    int forzada = random(0, NUM_ZONAS);
    colorZona[forzada] = colorObjetivo4;
    encenderZonaColor(forzada, colorObjetivo4);
  }

  // 4️⃣ reproducir audio
  reproducirAudioColor(colorObjetivo4);

  tableroListo4 = true;
}
void manejarModo4() {

  if (!tableroListo4) {
    generarModo4();
  }

  int z = leerZonaTocada();

  if (z != -1) {

    if (colorZona[z] == colorObjetivo4) {
      parpadearFeedback(VERDE);
    } else {
      parpadearFeedback(ROJO);
    }

    delay(600);
    tableroListo4 = false;
  }
}

//MODO 2
void generarPar() {
  par1 = random(0, NUM_ZONAS);
  do {
    par2 = random(0, NUM_ZONAS);
  } while (par2 == par1);
}

void mostrarPar() {
  encenderZona(par1, COLOR_PAR);
  encenderZona(par2, COLOR_PAR);
  delay(800);

  apagarZona(par1);
  apagarZona(par2);

  mostrandoPar = false;
  esperandoPar = true;

  seleccion1 = -1;
  seleccion2 = -1;
}


void leerParJugador(int zona) {

  // feedback visual
  encenderZona(zona, BLANCO);
  delay(200);
  apagarZona(zona);

  if (seleccion1 == -1) {
    seleccion1 = zona;
  } else if (seleccion2 == -1 && zona != seleccion1) {
    seleccion2 = zona;
  }

  // cuando ya hay 2 selecciones
  if (seleccion1 != -1 && seleccion2 != -1) {
    validarPar();
  }
}

void validarPar() {

  if (
    (seleccion1 == par1 && seleccion2 == par2) || (seleccion1 == par2 && seleccion2 == par1)) {
    // ✔ correcto
    parCorrecto();
  } else {
    // ❌ incorrecto
    parIncorrecto();
  }
}


void parCorrecto() {

  parpadearFeedback(VERDE);

  generarPar();
  mostrandoPar = true;
  esperandoPar = false;
}

void parIncorrecto() {

  parpadearFeedback(ROJO);

  mostrandoPar = true;
  esperandoPar = false;
}

//MODO3
void leerIdioma() {
  if (digitalRead(KICHWA) == HIGH & digitalRead(IDIOMA)==LOW) {
    idiomaActual = IDIOMA_ESP;
  } else if (digitalRead(KICHWA) == LOW & digitalRead(IDIOMA)==HIGH) {
   idiomaActual = IDIOMA_KICHWA;

  }else if (digitalRead(KICHWA) == HIGH & digitalRead(IDIOMA)==HIGH){
    idiomaActual = IDIOMA_INGLES;
  }

  // if (digitalRead(IDIOMA) == LOW) {
  //   idiomaActual = IDIOMA_INGLES;
  // } else {
  //   idiomaActual = IDIOMA_ESP;
  // }
}

void generarColor() {
  colorActual = random(0, 3);
  zonaCorrecta = random(0, NUM_ZONAS);
}


void reproducirAudioColor(int color) {

  if (idiomaActual == IDIOMA_ESP) {
    // 🇪🇸 ESPAÑOL
    if (color == C_ROJO) mp3.playTrackNumber(5, VOL_AUDIO);
    if (color == C_AZUL) mp3.playTrackNumber(2, VOL_AUDIO);
    if (color == C_AMARILLO) mp3.playTrackNumber(1, VOL_AUDIO);

  } else if (idiomaActual == IDIOMA_INGLES){
    // 🇬🇧 INGLÉS
    if (color == C_ROJO) mp3.playTrackNumber(4, VOL_AUDIO);
    if (color == C_AZUL) mp3.playTrackNumber(3, VOL_AUDIO);
    if (color == C_AMARILLO) mp3.playTrackNumber(6, VOL_AUDIO);
  }
  else if (idiomaActual == IDIOMA_KICHWA){
    // 🇬🇧 INGLÉS
    if (color == C_ROJO) mp3.playTrackNumber(7, VOL_AUDIO);
    if (color == C_AZUL) mp3.playTrackNumber(9, VOL_AUDIO);
    if (color == C_AMARILLO) mp3.playTrackNumber(8, VOL_AUDIO);
  }
}


void mostrarColor() {

  reproducirAudioColor(colorActual);

  switch (colorActual) {

    case C_ROJO:
      encenderZona(zonaCorrecta, ROJO);
      break;

    case C_AZUL:
      encenderZona(zonaCorrecta, AZUL);
      break;

    case C_AMARILLO:
      encenderZona(zonaCorrecta, AMARILLO);
      break;
  }

  tColor = millis();
  estadoColor = COLOR_MOSTRAR;
}


void manejarModoColor() {

  unsigned long ahora = millis();

  switch (estadoColor) {

    case COLOR_INIT:
      generarColor();
      mostrarColor();
      break;

    case COLOR_MOSTRAR:
      if (ahora - tColor >= 900) {
        apagarZona(zonaCorrecta);
        estadoColor = COLOR_ESPERAR;
      }
      break;

    case COLOR_ESPERAR:
      int zona = leerZonaTocada();
      if (zona != -1) {
        validarColor(zona);
      }
      break;
  }
}



void validarColor(int zona) {

  encenderZona(zona, BLANCO);
  delay(150);
  apagarZona(zona);

  if (zona == zonaCorrecta) {
    parpadearFeedback(VERDE);
  } else {
    parpadearFeedback(ROJO);
  }

  estadoColor = COLOR_INIT;
}

void loop() {

  leerModo();
  leerIdioma();
  switch (modoActual) {

    case MODO_COLOR_TOTAL:
      manejarModo4();
      break;

    case MODO_PAR:
      if (mostrandoPar) mostrarPar();
      if (esperandoPar) {
        int z = leerZonaTocada();
        if (z != -1) leerParJugador(z);
      }
      break;

    case MODO_COLOR:
      manejarModoColor();
      break;
  }
  if (millis() - tDebug >= DEBUG_INTERVAL) {
    tDebug = millis();
    mostrarSensoresMatriz();
    mostrarInputs();
  }
  delay(10);  // loop fluido
}


// MODO1
// void loop() {

//   if (mostrandoSecuencia) {
//     mostrarSecuencia();
//   }

//   if (esperandoJugador) {
//     int zona = leerZonaTocada();
//     if (zona != -1) {
//       validarJugador(zona);
//       delay(250);  // antirebote simple
//     }
//   }
// }


//MODO2
// void loop() {

//   if (mostrandoPar) {
//     mostrarPar();
//   }

//   if (esperandoPar) {
//     int zona = leerZonaTocada();
//     if (zona != -1) {
//       leerParJugador(zona);
//       delay(250);  // antirebote
//     }
//   }

// }


//MODO3
// void loop() {
//   actualizarIdioma();

//   if (dictandoColor) {
//     dictarColor();
//   }

//   if (esperandoColor) {
//     int zona = leerZonaTocada();
//     if (zona != -1) {
//       validarColor(zona);
//       delay(250);
//     }
//   }

// }
